const express = require('express');
const server = express();
const path = require('path');
const sql = require('./db/db');
const bodyParser = require('body-parser');
const crud = require('./db/CRUD');
const port = 3000;

server.use(express.static(path.join(__dirname, "/static")));
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({ extended: true }));

crud.dropTablesQuery();
crud.createTables();
console.log("Created all of the tables for the web :)");

// Routes
server.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, "views/Login.html"));
});

server.get('/Login.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/Login.html"));
});

server.get('/UpdatePassword.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/UpdatePassword.html"));
});

server.get('/SignUp.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/SignUp.html"));
});

server.get('/HomePage.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/HomePage.html"));
});

server.get('/CommunityPage.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/CommunityPage.html"));
});

server.get('/CommunityTab.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/CommunityTab.html"));
});

server.get('/ProfilePage.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/ProfilePage.html"));
});

server.get('/MessagesPage.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/MessagesPage.html"));
});

server.get('/NotificationsPage.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/NotificationsPage.html"));
});

server.get('/NewPost.html', (req, res) => {
  res.sendFile(path.join(__dirname, "views/NewPost.html"));
});

server.post('/Login', crud.checkCredentials);

server.post('/SignUp', crud.createNewUser);

server.post('/UpdatePassword', crud.updatePassword);

server.get('/SearchCommunity', crud.searchCommunityByName);

server.get('/DeleteTables', (req, res) => {
  const dropTablesQuery = `DROP TABLE IF EXISTS relations, posted, joined, comments, communities, users, posts`;

  sql.query(dropTablesQuery, (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).send("Failed to delete tables");
      return;
    }
    res.send("Tables deleted successfully");
    console.log("Tables deleted successfully");
  });
});

server.listen(port, () => {
  console.log("Server is running on port", port);
});

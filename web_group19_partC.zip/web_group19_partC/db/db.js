const web = require('mysql2');
const dbConfig = require('./db.config');

const connection = web.createConnection({
    host: dbConfig.HOST,
    user : dbConfig.USER,
    password: dbConfig.PASSWORD,
    database: dbConfig.DATABASE

});

connection.connect(error => {
    if (error) throw error;
    console.log("Connected to web database")

});

module.exports = connection;
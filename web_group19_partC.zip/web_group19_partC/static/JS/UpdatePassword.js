const myForm = document.querySelector("#my-form");
const url = "/UpdatePassword";

const onSubmit = (e) => {
  e.preventDefault();

  const userNameInput = document.querySelector("#userName");
  const oldPasswordInput = document.querySelector("#oldpassword");
  const newPasswordInput = document.querySelector("#newpassword");
  const confirmPasswordInput = document.querySelector("#confirmPassword");

  const userName = userNameInput.value.trim();
  const oldPassword = oldPasswordInput.value.trim();
  const newPassword = newPasswordInput.value.trim();
  const confirmPassword = confirmPasswordInput.value.trim();

  if (userName.length === 0 || oldPassword.length === 0 || newPassword.length === 0 || confirmPassword.length === 0) {
    alert("Please fill in all the fields.");
    return;
  }

  if (newPassword !== confirmPassword) {
    alert("New password and confirm password do not match.");
    return;
  }

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
        username: userName,
        oldPassword: oldPassword,
        newPassword: newPassword
      }),
  })
    .then((response) => {
      if (response.ok) {
        alert("Password updated successfully.");
        window.location.href = "Login.html"; // Redirect to login page after successful update
      } else if (response.status === 401) {
        alert("Incorrect username or password.");
      } else {
        throw new Error("Password update failed.");
      }
    })
    .catch((error) => alert(error));
};

myForm.addEventListener("submit", onSubmit);

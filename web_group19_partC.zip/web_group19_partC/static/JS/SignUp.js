//const { response } = require("express");

const myForm = document.querySelector("#my-form");
const url = "/SignUp";

const onsubmit = (e) => {

  const emailInput = document.querySelector("#email");
  const userNameInput = document.querySelector("#userName");
  const passwordInput = document.querySelector("#password");
  const confirmPasswordInput = document.querySelector("#confirmPassword");

  const email = emailInput.value.trim();
  const username = userNameInput.value.trim();
  const password = passwordInput.value.trim();
  const confirmPassword = confirmPasswordInput.value.trim();

  if (email === "" || username === "" || password === "" || confirmPassword === "") {
    e.preventDefault();
    alert("Please fill in all the fields.");
  } else if (!isValidEmail(email)) {
    e.preventDefault();
    alert("Please enter a valid email address.");
  } else if (username.includes(" ")) {
    e.preventDefault();
    alert("Username should not contain spaces.");
  } else if (password.length < 6) {
    e.preventDefault();
    alert("Password should be at least 6 characters long.");
  } else if (password !== confirmPassword) {
    e.preventDefault();
    alert("Passwords do not match.");
  } else {
    // alert("Successfully signed up")
    e.preventDefault();
  
    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email,
        username,
        password
      })
    })
    .then(response => {
      if (response.ok) {
        window.location.href = "/Login.html";
      } else {
        throw new Error("Sign up failed email or user name already exist");
      }
    })
    .catch(error => {
      alert(error.message);
    });
};
};

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

myForm.addEventListener("submit", onsubmit);
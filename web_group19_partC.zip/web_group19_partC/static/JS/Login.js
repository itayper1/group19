const myForm = document.querySelector("#my-form");
const url = "/Login";

    const onsubmit = (e) => {
      

      const userNameInput = document.querySelector("#username");
      const passwordInput = document.querySelector("#password");

      const username = userNameInput.value.trim();
      const password = passwordInput.value.trim();

      if (username.length === 0 || password.length === 0) {
        e.preventDefault();
        alert("Please enter both username and password.");
        return
      } 
      else {
        e.preventDefault();

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        username,
        password
      })
    })
    .then(response => {
      if (response.status === 401) {
        return response.text().then(errorMessage => {
          if (errorMessage === "Username does not exist") {
            alert("Username does not exist");
          } else if (errorMessage === "Incorrect password") {
            alert("Incorrect password");
          } else {
            alert("Login failed Incorrect password or user name");
          }
        });
      } else if (response.ok) {
        window.location.href = "/HomePage.html";
      } else {
        throw new Error("Login failed");
      }
    })
    .catch(error => alert(error));
  }
    
    };
  
myForm.addEventListener("submit", onsubmit);
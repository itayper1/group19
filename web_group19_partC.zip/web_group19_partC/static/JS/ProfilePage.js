const followButton = document.querySelector('.followButton') 

followButton.addEventListener('click', function onClick() {
    document.querySelector('.followButton').style.backgroundColor = 'limegreen'
    document.querySelector('.followButton').style.color = 'white'
    document.querySelector('.followButton').style.border = '0px'
    document.querySelector('.followButton').innerHTML = 'FOLLOWING'
})

const followrs = document.querySelector('.profileFollowers')

followers.addEventListener('click', function onClick() {
    
})
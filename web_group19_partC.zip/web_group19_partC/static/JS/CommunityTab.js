const form = document.querySelector("#my-form");
const url = "/SearchCommunity";

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const communityInput = document.querySelector("#community");
  const communityName = communityInput.value;

  fetch(`${url}?name=${communityName}`)
    .then((response) => response.json())
    .then((data) => {
      const communityContainer = document.querySelector(".communityContainer");
      communityContainer.innerHTML = "";

      if (data.communities.length === 0) {
        alert("There is no such community.");
      } else {
        data.communities.forEach((community) => {
          const communityDiv = document.createElement("div");
          communityDiv.classList.add("community");

          const communityName = document.createElement("h3");
          communityName.textContent = community.name;

          const communityDescription = document.createElement("p");
          communityDescription.textContent = community.description;

          communityDiv.appendChild(communityName);
          communityDiv.appendChild(communityDescription);

          communityContainer.appendChild(communityDiv);
        });
      }
    })
    .catch((error) => console.log(error));
});
